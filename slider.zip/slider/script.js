"use strict";

const sliderLeft = document.querySelector(".slider-button-left");
const sliderRight = document.querySelector(".slider-button-right");
const card = document.querySelectorAll(".card");

var move = 0;
var totalCards = card.length;

sliderRight.addEventListener("click", function () {
  if (move === (totalCards - 1) * 100) move = -100;
  move = move + 100;
  movecard(move);
});

sliderLeft.addEventListener("click", function () {
  if (move === 0) move = totalCards * 100;
  move = move - 100;
  movecard(move);
});

function movecard(moveValue) {
  card.forEach((cardItem) => {
    cardItem.style.transform = `translateX(${-moveValue}%)`;
  });
}
